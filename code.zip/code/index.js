//lib
var express = require('express');
var router = express.Router();
//controllers


const tagController = require('../controller').tag;
const searchController = require('../controller').search;
const uploadController = require('../controller').upload;
const buildController = require('../controller').build;
//home rought
router.get(
    '/api',
    (req, res) => res.status(200).send({message: 'Welcome to the IM-GIT-MS!'})
);

//session routes
router.post('/api/createTag', tagController.create);


router.get('/api/getTemplate',searchController.getTemplate); 
router.post('/api/getTemplate',searchController.create); 
router.get('/api/getTemplate/:searchId',searchController.getTemplateByID);
router.put('/api/getTemplate/:searchId',searchController.updateTemplateByID);
router.delete('/api/getTemplate/:searchId',searchController.deleteTemplateByID);


router.get('/api/getUserActivity',uploadController.getActivity); 
router.post('/api/getUserActivity',uploadController.create);

module.exports = router;