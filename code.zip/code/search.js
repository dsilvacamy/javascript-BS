 const search = require('../models').t_tamplete_category;

 var ShortUniqueId = require('short-unique-id');
 var uid = new ShortUniqueId();
 var logger = require("../utils/logger");
var Sequelize = require('sequelize');

 module.exports = {
     create(req, res) {
        return search
            .create({
             cat_id: uid.randomUUID(10),
            cat_name: req.body.name,
            sub_cat_name: req.body.subName,
            is_valid:true
        })
         .then((search) => {
        res.status(201).send(search)
         })
         .catch((err) => res.status(400).send(err));
         }, 

         getTemplate(req, res) {
            return search
                .all()
             .then((search) => {
            res.status(201).send(search)
             })
             .catch((err) => res.status(400).send(err));
             },

        getTemplateByID(req, res){
            return search
            .findById(req.params.searchId)
            .then((search) => {
                res.status(201).send(search)
                 })
                 .catch((err) => res.status(400).send(err));
                 },

        updateTemplateByID(req, res){
            return search
           .update({
            //cat_id: uid.randomUUID(10),
            cat_name: req.body.name,
            sub_cat_name: req.body.subName,
           // is_valid:true
           },{where : {cat_id: req.params.searchId} })
           .then((search) => {
            res.status(201).send(search)
             })
             .catch((err) => res.status(400).send(err));
             },

            deleteTemplateByID(req, res){
                return search
            .update({ is_valid:false},{where : {cat_id: req.params.searchId}})
            .then((search) => {
                res.status(201).send(search)
                 })
                 .catch((err) => res.status(400).send(err));


        },

        

    
 };