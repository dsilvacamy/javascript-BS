const userActivity = require('../models').t_user_activity;

 var ShortUniqueId = require('short-unique-id');
 var uid = new ShortUniqueId();
 var logger = require("../utils/logger");
var Sequelize = require('sequelize');

 module.exports = {
     create(req, res) {
        return userActivity
            .create({
            activity_id: uid.randomUUID(10),
            keyword: req.body.keyword,
            activity_type: req.body.activity_type
        })
         .then((userActivity) => {
        res.status(201).send(userActivity)
         })
         .catch((err) => res.status(400).send(err));
         }, 

         getActivity(req, res) {
            return userActivity
                .all()
             .then((userActivity) => {
            res.status(201).send(userActivity)
             })
             .catch((err) => res.status(400).send(err));
             },
             
};